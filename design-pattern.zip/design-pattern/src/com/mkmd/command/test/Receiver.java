package com.mkmd.command.test;

/**
 * 命令接受 执行结果
 * 
 * @author mahd
 *
 */
public class Receiver {
	public void action() {
		System.out.println("command received!");
	}
}
