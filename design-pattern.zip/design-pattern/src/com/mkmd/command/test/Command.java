package com.mkmd.command.test;

/**
 * 命令接口
 * 
 * @author mahd
 *
 */
public interface Command {
	public void exe();
}
