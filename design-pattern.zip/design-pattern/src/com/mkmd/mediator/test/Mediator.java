package com.mkmd.mediator.test;

/**
 * 中介接口
 * 
 * @author mahd
 *
 */
public interface Mediator {
	public void createMediator();

	public void workAll();
}
