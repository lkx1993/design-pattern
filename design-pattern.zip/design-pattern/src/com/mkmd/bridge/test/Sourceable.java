package com.mkmd.bridge.test;

/**
 * 定义资源接口
 * 
 * @author mahd
 *
 */
public interface Sourceable {
	public void method();
}