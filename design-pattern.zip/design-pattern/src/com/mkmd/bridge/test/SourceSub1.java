package com.mkmd.bridge.test;

/**
 * 资源实现类1
 * 
 * @author mahd
 *
 */
public class SourceSub1 implements Sourceable {

	@Override
	public void method() {
		System.out.println("this is the first sub!");
	}

}
