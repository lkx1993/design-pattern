package com.mkmd.facade.test;

public class Main {
	public static void main(String[] args) {
		ComputerAction computer = new ComputerAction();
		computer.startup();
		computer.shutdown();
	}

}
