package com.mkmd.proxy.test;

public class Main {

	public static void main(String[] args) {
		Sourceable source = new Proxy();
		source.method();
	}

}
