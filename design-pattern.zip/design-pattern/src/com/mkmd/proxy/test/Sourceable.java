package com.mkmd.proxy.test;

/**
 * 定义资源类和代理类的共有接口
 * 
 * @author mahd
 *
 */
public interface Sourceable {
	public void method();
}
