package com.mkmd.adapter.test;

public abstract class Print2 {
	/**
	 * 弱化输出
	 */
	public abstract void printWeak();

	/**
	 * 强化输出
	 */
	public abstract void printStrong();
}
