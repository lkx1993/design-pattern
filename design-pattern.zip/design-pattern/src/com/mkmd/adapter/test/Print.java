package com.mkmd.adapter.test;

/**
 * 
 * @author mahd
 *
 */
public interface Print {
	/**
	 * 弱化输出
	 */
	public abstract void printWeak();

	/**
	 * 强化输出
	 */
	public abstract void printStrong();

}
