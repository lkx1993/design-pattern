package com.mkmd.observer.test;

/**
 * 观察者接口
 * 
 * @author mahd
 *
 */
public interface Observer {
	public void update();
}
