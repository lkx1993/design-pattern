package com.mkmd.decorator.test;

/**
 * 被装饰类
 * 
 * @author mahd
 *
 */
public interface Sourceable {
	public void method();
}
